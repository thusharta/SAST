# Critical security vulnerability example

import os

def execute_command(user_input):
    # CRITICAL: Command injection vulnerability
    os.system(user_input)  # Direct execution of user input
    
# Example usage
if __name__ == "__main__":
    user_command = input("Enter command: ")
    execute_command(user_command)
